# Heart Disease prediction ML app using Streamlit
You will find the dataset on Kaggle:https://www.kaggle.com/datasets/johnsmith88/heart-disease-dataset
the jupyter notebook is to create the ML model and the app.py is for the streamlit application.
